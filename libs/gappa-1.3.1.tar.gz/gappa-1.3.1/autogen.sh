#!/bin/sh
touch ChangeLog stamp-config_h.in
autoreconf -i -s
